package com.company;

import java.util.Random;
import java.util.Scanner;

public class SPS {
    public static void main(String[] args) {
        // Initilize the scanner and random
        int r = (int)(Math.random()*3);

        Scanner sc = new Scanner(System.in);
        System.out.println("Lets Play Stone Paper Scissor");

        // Use While loop for ture if want to play game and quit if want to quite game
        while(true) {
            System.out.println("What is your Move? To enter your next move Enter Either Rock or Paper or Scissor ");
            String myMove = sc.nextLine();

            //Check if user wants quit:
            if(myMove.equals("quit")){
                System.out.println("Thanks To visit Once");
                break;
            }
            // Check if users move is valid or not:
             if(!myMove.equals("rock") && !myMove.equals("scissor") && !myMove.equals("paper")){
                 System.out.println("Your move is invalid");
             }
             else {
                 String opponentMove = "";
                 if(r == 0){
                     opponentMove = "rock";
                 }
                 else if (r == 1){
                     opponentMove = "paper";
                 }
                 else{
                     opponentMove = "scissor";
                 }
                 System.out.println("oppnent move " + opponentMove);

                 //print result of the game win-loss-tie:
                 if(myMove.equals(opponentMove)){
                     System.out.println("Its a tie");
                 }
                 else if(myMove.equals("rock") && opponentMove.equals("scissor") || myMove.equals("paper") && opponentMove.equals("rock") || myMove.equals("scissor") && opponentMove.equals("paper")) {
                     System.out.println("You Won");
                 }

                 else {
                     System.out.println("You lost ^_^ ");

             }

            }


        }
        //Final message for user:
        System.out.println("Thanks for Playing Game ");
    }
}
